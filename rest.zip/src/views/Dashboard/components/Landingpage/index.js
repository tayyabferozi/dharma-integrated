export { default } from './Landingpage';
